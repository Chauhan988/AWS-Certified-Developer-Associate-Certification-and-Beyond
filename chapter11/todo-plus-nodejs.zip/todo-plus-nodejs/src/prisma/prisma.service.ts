import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { databasePassword, databaseUsername } from 'src/main';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  constructor() {
    if (!databaseUsername || !databasePassword) {
      throw Error('databaseUsername, databasePassword required.');
    }
    const DB_PORT = process.env.DB_PORT ?? '3306';
    const DB_HOST = process.env.DB_HOST;
    if (!DB_HOST) {
      throw Error('DB_HOST is required.');
    }
    super({
      datasources: {
        db: {
          url: `mysql://${databaseUsername}:${databasePassword}@${DB_HOST}:${DB_PORT}/todo-plus?allowPublicKeyRetrieval=true&useSSL=false`,
        },
      },
    });
  }
  async onModuleInit() {
    await this.$connect();
  }
}
